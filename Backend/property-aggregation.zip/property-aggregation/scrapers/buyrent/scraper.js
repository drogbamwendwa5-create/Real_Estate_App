const BaseScraper = require("../base/BaseScraper");
const P = require("./parser");
const E = require("./extractor");
const V = require("./validator");
const sc = require("../../config/source.config");

class BuyRentScraper extends BaseScraper {
  constructor() {
    super("buyrent", sc.sources.buyrent);
    this.p = new P();
    this.e = new E();
    this.v = new V();
  }

  async scrapeListingPage(p) {
    const u = p === 1 ? this.config.baseUrl + "/listings" : this.config.baseUrl + "/listings?page=" + p;
    const h = await this.fetchHTML(u);
    const $ = this.loadCheerio(h);
    const urls = [];
    $(".property-card a, .listing-card a, a[href*='/listings/']").each((_, e) => {
      const h2 = $(e).attr("href");
      if (h2 && h2.includes("/listings/") && !urls.includes(h2)) {
        urls.push(h2.startsWith("http") ? h2 : this.config.baseUrl + h2);
      }
    });
    return urls;
  }

  async scrapePropertyDetail(u) {
    const h = await this.fetchHTML(u);
    const $ = this.loadCheerio(h);
    const raw = this.e.extract($, u, this.config.baseUrl);
    const property = this.p.parse(raw);
    const v = this.v.validate(property);
    if (v.isValid) return v.data;
    return null;
  }
}

module.exports = BuyRentScraper;