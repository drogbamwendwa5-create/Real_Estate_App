const BaseScraper = require('../base/BaseScraper');
const PropertyNormalizer = require('../../utils/PropertyNormalizer');
const sc = require('../../config/source.config');

class WebSearchScraper extends BaseScraper {
  constructor() {
    super('websearch', sc.sources.websearch);
  }

  async scrapeListingPage(page = 1) {
    try {
      const query = 'kenya property for sale';
      const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&start=${(page - 1) * 10}`;
      const html = await this.fetchHTML(url);
      const $ = this.loadCheerio(html);
      const urls = [];
      const seen = new Set();

      $('a').each((_, el) => {
        const href = $(el).attr('href');
        if (!href) return;
        const cleaned = this.normalizeLink(href);
        if (!cleaned || cleaned.includes('google.com') || cleaned.includes('/search?') || cleaned.includes('/imgres?')) return;
        if (seen.has(cleaned)) return;
        seen.add(cleaned);
        urls.push(cleaned);
      });

      return urls.filter((u) => /property|listing|home|house|apartment|rent|sale/i.test(u)).slice(0, 6);
    } catch (error) {
      console.warn('[WebSearchScraper] Failed to scrape listing page:', error.message);
      return [];
    }
  }

  normalizeLink(href) {
    if (!href) return '';
    const withoutTracking = href.replace('/url?q=', '').split('&')[0];
    return withoutTracking.startsWith('http') ? withoutTracking : '';
  }

  async scrapePropertyDetail(url) {
    try {
      const html = await this.fetchHTML(url);
      const $ = this.loadCheerio(html);
      const title = $('title').first().text().trim() || 'Property listing';
      const description = $('meta[name="description"]').attr('content') || $('body').text().trim();
      const priceText = $('body').text().match(/KSh[^\n]{0,20}|KES[^\n]{0,20}|\b\d{1,3}(,\d{3})+(\.\d+)?\b/);
      const combinedText = `${title}\n${description}`.toLowerCase();

      if (!/(property|listing|house|apartment|home|rent|sale)/i.test(combinedText)) {
        return null;
      }

      return PropertyNormalizer.normalize({
        title,
        description: description.substring(0, 400),
        price: priceText ? priceText[0] : '0',
        listingType: 'for-sale',
        propertyType: 'house',
        sourceURL: url,
        sourceID: url,
        sourceCategory: 'web-search',
        promotionType: 'web-search',
        isVerifiedAgent: false,
        verifiedStatus: 'pending',
        images: [$('img').first().attr('src')].filter(Boolean),
      }, 'websearch');
    } catch (error) {
      return null;
    }
  }
}

module.exports = WebSearchScraper;
