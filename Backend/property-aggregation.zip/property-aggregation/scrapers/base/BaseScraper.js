const axios = require("axios");
const cheerio = require("cheerio");
const sc = require("../../config/source.config");

class BaseScraper {
  constructor(sk, cfg) {
    this.sourceKey = sk;
    this.config = cfg;
    this.axiosInstance = axios.create({
      timeout: sc.axios.timeout,
      maxRedirects: sc.axios.maxRedirects,
      headers: (cfg && cfg.headers) || sc.defaults.headers,
    });
  }

  async fetchWithAxios(url) {
    const r = await this.axiosInstance.get(url);
    return r.data;
  }

  async fetchWithPuppeteer(url) {
    let b = null;
    try {
      const p = require("puppeteer");
      b = await p.launch(sc.puppeteer);
      const page = await b.newPage();
      if (this.config && this.config.headers && this.config.headers["User-Agent"]) {
        await page.setUserAgent(this.config.headers["User-Agent"]);
      }
      await page.goto(url, { waitUntil: sc.puppeteer.waitUntil, timeout: sc.puppeteer.timeout });
      const html = await page.content();
      return html;
    } finally {
      if (b) await b.close();
    }
  }

  async fetchHTML(url, fp) {
    if (fp || (this.config && this.config.usePuppeteer)) return this.fetchWithPuppeteer(url);
    try {
      return await this.fetchWithAxios(url);
    } catch (e) {
      return this.fetchWithPuppeteer(url);
    }
  }

  loadCheerio(html) {
    return cheerio.load(html);
  }

  async rateLimit() {
    const delay = (this.config && this.config.rateLimitMs) || sc.defaults.rateLimitMs;
    await new Promise((r) => setTimeout(r, delay));
  }

  async scrapeListingPage(p) {
    throw new Error("Must implement");
  }

  async scrapePropertyDetail(u) {
    throw new Error("Must implement");
  }

  /**
   * Scrape properties with a time limit of 5 minutes (300,000ms).
   * Instead of a fixed maxPages, the scraper runs until the time limit is reached
   * or no more pages are available, whichever comes first.
   */
  async scrape(o = {}) {
    const start = new Date();
    const maxRuntime = o.maxRuntime || 300000; // 5 minutes default
    const mp = o.maxPages || (this.config && this.config.maxPages) || 50; // Allow up to 50 pages but time-bound
    const all = [];
    let pages = 0;
    let errors = [];

    for (let p = 1; p <= mp; p++) {
      // Check if we've exceeded the runtime limit
      const elapsed = Date.now() - start.getTime();
      if (elapsed >= maxRuntime) {
        console.log(`[${this.sourceKey}] Runtime limit reached (${elapsed}ms). Stopping after page ${p}.`);
        break;
      }

      try {
        await this.rateLimit();
        const urls = await this.scrapeListingPage(p);
        pages++;
        if (!urls || urls.length === 0) break;

        for (const u of urls) {
          // Check runtime before each detail scrape
          const elapsed2 = Date.now() - start.getTime();
          if (elapsed2 >= maxRuntime) {
            console.log(`[${this.sourceKey}] Runtime limit reached during detail scraping. Stopping.`);
            break;
          }

          try {
            await this.rateLimit();
            const d = await this.scrapePropertyDetail(u);
            if (d) {
              // Ensure images are captured - if no images, add a placeholder
              if (!d.images || d.images.length === 0) {
                if (!d.propertyImages || d.propertyImages.length === 0) {
                  d.images = ['https://via.placeholder.com/600x400?text=No+Image+Available'];
                }
              }
              all.push(d);
            }
          } catch (e) {
            errors.push({ message: e.message, url: u, timestamp: new Date() });
          }
        }

        // Break out of page loop if we hit runtime during detail scraping
        if (Date.now() - start.getTime() >= maxRuntime) break;
      } catch (e) {
        errors.push({ message: e.message, url: "page:" + p, timestamp: new Date() });
        if (errors.length > 10) break;
      }
    }

    return {
      sourceKey: this.sourceKey,
      status: errors.length > 0 ? "partial" : "success",
      startedAt: start,
      completedAt: new Date(),
      durationMs: Date.now() - start.getTime(),
      pagesScraped: pages,
      listingsFound: all.length,
      listings: all,
      errors,
    };
  }
}

module.exports = BaseScraper;