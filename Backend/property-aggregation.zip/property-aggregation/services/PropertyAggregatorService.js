const sc = require("../config/source.config");
const PropertyImportService = require("./PropertyImportService");
const ScraperLogger = require("../logger/ScraperLogger");

class PropertyAggregatorService {
  constructor() {
    this.importService = new PropertyImportService();
    this.scrapers = {};
    this.loggers = {};
    for (const [key, cfg] of Object.entries(sc.sources)) {
      if (cfg.enabled) {
        try {
          const ScraperClass = require("../scrapers/" + key + "/scraper");
          this.scrapers[key] = new ScraperClass();
          this.loggers[key] = new ScraperLogger(key);
        } catch (e) {
          console.warn("[Aggregator] Failed to load scraper " + key + ":", e.message);
        }
      }
    }
  }

  /**
   * Aggregate all sources with a 5-minute timeout per scraper.
   * Each scraper runs for up to 5 minutes (300,000ms) and saves results
   * directly to the database via PropertyImportService.
   */
  async aggregateAllSources() {
    const results = {};
    for (const [key, scraper] of Object.entries(this.scrapers)) {
      try {
        console.log("[Aggregator] Scraping " + key + "...");
        
        // Run the scraper with a 5-minute timeout using Promise.race
        const scrapePromise = scraper.scrape({ maxRuntime: 300000 });
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error("Scraper " + key + " timed out after 5 minutes")), 300000)
        );
        
        const scrapeResult = await Promise.race([scrapePromise, timeoutPromise]);
        
        const listings = Array.isArray(scrapeResult.listings) ? scrapeResult.listings : [];
        
        // Import scraped properties to the database
        console.log(`[Aggregator] Importing ${listings.length} properties from ${key} to database...`);
        const importResult = await this.importService.import(listings, key);
        
        await this.loggers[key].logScrapeRun({
          ...scrapeResult,
          ...importResult,
          sourceName: sc.sources[key]?.name || key,
        });
        
        results[key] = {
          source: key,
          status: scrapeResult.status,
          listingsFound: scrapeResult.listingsFound,
          listingsImported: importResult.imported,
          listingsUpdated: importResult.updated,
          errors: scrapeResult.errors,
        };
        
        console.log(`[Aggregator] ${key} completed: ${importResult.imported} imported, ${importResult.updated} updated, ${importResult.failed} failed`);
      } catch (e) {
        console.error("[Aggregator] Error scraping " + key + ":", e.message);
        if (this.loggers[key]) this.loggers[key].logError("scrape", e);
        results[key] = { source: key, status: "failed", error: e.message };
      }
    }
    return results;
  }
}

module.exports = PropertyAggregatorService;