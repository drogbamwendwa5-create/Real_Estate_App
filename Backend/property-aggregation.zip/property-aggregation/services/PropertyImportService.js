/**
 * Property Import Service
 * Batch import of properties from various data sources.
 * Ensures all properties have valid images before saving to the database.
 */
const AggregatedProperty = require('../database/AggregatedProperty');

class PropertyImportService {
  async import(properties, sourceName) {
    if (!Array.isArray(properties)) {
      return { imported: 0, updated: 0, failed: 0 };
    }
    return await this.importFromArray(properties, sourceName);
  }

  /**
   * Ensure a property has at least one valid image.
   * If no images are found, attempt to add a placeholder.
   */
  ensureImages(property) {
    // Check both formats: propertyImages (database format) and images (extractor format)
    const hasPropertyImages = property.propertyImages && 
      Array.isArray(property.propertyImages) && 
      property.propertyImages.length > 0 &&
      property.propertyImages.some(img => img && img.url);
    
    const hasImages = property.images && 
      Array.isArray(property.images) && 
      property.images.length > 0 &&
      property.images.some(img => {
        if (typeof img === 'string') return img;
        return img && (img.url || img.src);
      });

    if (!hasPropertyImages && !hasImages) {
      // Add a placeholder image
      const placeholder = 'https://via.placeholder.com/600x400?text=No+Image+Available';
      property.propertyImages = [{ url: placeholder, isFeatured: true, isValid: true }];
      property.images = [placeholder];
    }
    
    return property;
  }

  async processProperty(property, sourceName) {
    if (!property || !property.propertyID) {
      return { success: false, error: 'Invalid property data' };
    }

    // Ensure images are present
    property = this.ensureImages(property);

    property.sourceName = property.sourceName || sourceName;
    property.lastUpdated = new Date();

    try {
      const existing = await AggregatedProperty.findOne({ propertyID: property.propertyID });
      if (existing) {
        await AggregatedProperty.findOneAndUpdate(
          { propertyID: property.propertyID },
          { ...property },
          { new: true, runValidators: true }
        );
        return { success: true, isUpdate: true };
      }

      await AggregatedProperty.create({ ...property });
      return { success: true, isUpdate: false };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async importBatch(properties, sourceName) {
    let imported = 0;
    let updated = 0;
    let failed = 0;

    for (const raw of properties) {
      const result = await this.processProperty(raw, sourceName);
      if (result.success) {
        if (result.isUpdate) updated++;
        else imported++;
      } else {
        failed++;
      }
    }

    return { imported, updated, failed };
  }

  async importFromFile(filePath, sourceName) {
    const fs = require('fs');
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return await this.importBatch(data, sourceName);
  }

  async importFromArray(properties, sourceName) {
    return await this.importBatch(properties, sourceName);
  }
}

module.exports = PropertyImportService;