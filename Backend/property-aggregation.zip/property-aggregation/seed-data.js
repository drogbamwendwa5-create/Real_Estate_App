/**
 * Seed the AggregatedProperty collection with sample properties.
 * Usage: node property-aggregation/seed-data.js
 */
const path = require('path');
const dotenv = require('dotenv');

dotenv.config({ path: path.join(__dirname, '..', '.env') });

const connectDB = require('../Config/database');
const AggregatedProperty = require('./database/AggregatedProperty');

const sampleProperties = [
  {
    propertyID: 'seed-001',
    sourceName: 'BuyRent Kenya',
    sourceID: 'br-001',
    title: 'Luxury 3 Bedroom Apartment in Kilimani',
    description: 'Spacious modern apartment with all amenities. Located in the heart of Kilimani with easy access to shopping malls, restaurants, and schools.',
    price: 85000,
    currency: 'KES',
    listingType: 'for-rent',
    propertyType: 'apartment',
    county: 'Nairobi',
    town: 'Nairobi',
    estate: 'Kilimani',
    bedrooms: 3,
    bathrooms: 2,
    size: 120,
    furnished: true,
    serviced: true,
    propertyImages: [
      { url: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267' },
      { url: 'https://images.unsplash.com/photo-1560448204-e02f11c3d2e7' },
    ],
    location: {
      type: 'Point',
      coordinates: [36.7820, -1.2921],
    },
    isPublished: true,
    isFeatured: true,
    availability: 'available',
    verifiedStatus: 'verified',
    postedDate: new Date(),
  },
  {
    propertyID: 'seed-002',
    sourceName: 'Property24 Kenya',
    sourceID: 'p24-001',
    title: '4 Bedroom Townhouse in Karen',
    description: 'Beautiful townhouse in a gated community in Karen. Spacious garden, servant quarters, and ample parking.',
    price: 12000000,
    currency: 'KES',
    listingType: 'for-sale',
    propertyType: 'house',
    county: 'Nairobi',
    town: 'Nairobi',
    estate: 'Karen',
    bedrooms: 4,
    bathrooms: 3,
    size: 350,
    furnished: false,
    serviced: false,
    propertyImages: [
      { url: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6' },
      { url: 'https://images.unsplash.com/photo-1600596542815-27bfef402323' },
    ],
    location: {
      type: 'Point',
      coordinates: [36.7070, -1.3197],
    },
    isPublished: true,
    isFeatured: true,
    availability: 'available',
    verifiedStatus: 'verified',
    postedDate: new Date(),
  },
  {
    propertyID: 'seed-003',
    sourceName: 'Kenya Property Centre',
    sourceID: 'kpc-001',
    title: '2 Bedroom Apartment for Rent in Westlands',
    description: 'Modern 2 bedroom apartment in Westlands. Close to Sarit Centre and Westgate Mall. Swimming pool and gym available.',
    price: 65000,
    currency: 'KES',
    listingType: 'for-rent',
    propertyType: 'apartment',
    county: 'Nairobi',
    town: 'Nairobi',
    estate: 'Westlands',
    bedrooms: 2,
    bathrooms: 2,
    size: 90,
    furnished: true,
    serviced: true,
    propertyImages: [
      { url: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267' },
    ],
    location: {
      type: 'Point',
      coordinates: [36.8025, -1.2676],
    },
    isPublished: true,
    isFeatured: false,
    availability: 'available',
    verifiedStatus: 'pending',
    postedDate: new Date(),
  },
  {
    propertyID: 'seed-004',
    sourceName: 'Hauzisha',
    sourceID: 'hz-001',
    title: 'Commercial Space for Rent in CBD',
    description: 'Prime commercial space in Nairobi CBD. Ground floor, high foot traffic area. Suitable for retail or office use.',
    price: 150000,
    currency: 'KES',
    listingType: 'for-rent',
    propertyType: 'commercial',
    county: 'Nairobi',
    town: 'Nairobi',
    estate: 'CBD',
    bedrooms: 0,
    bathrooms: 2,
    size: 200,
    furnished: false,
    serviced: true,
    propertyImages: [
      { url: 'https://images.unsplash.com/photo-1497366216548-37526070297c' },
    ],
    location: {
      type: 'Point',
      coordinates: [36.8219, -1.2864],
    },
    isPublished: true,
    isFeatured: false,
    availability: 'available',
    verifiedStatus: 'verified',
    postedDate: new Date(),
  },
  {
    propertyID: 'seed-005',
    sourceName: 'BuyRent Kenya',
    sourceID: 'br-002',
    title: 'Land for Sale in Ruaka',
    description: 'Prime 1/4 acre plot in Ruaka, near Two Rivers Mall. Ready title deed. Good for residential development.',
    price: 8000000,
    currency: 'KES',
    listingType: 'for-sale',
    propertyType: 'land',
    county: 'Kiambu',
    town: 'Ruaka',
    estate: 'Ruaka',
    bedrooms: 0,
    bathrooms: 0,
    size: 1012,
    furnished: false,
    serviced: false,
    propertyImages: [
      { url: 'https://images.unsplash.com/photo-1500382017468-9029d4c0a784' },
    ],
    location: {
      type: 'Point',
      coordinates: [36.7790, -1.2100],
    },
    isPublished: true,
    isFeatured: true,
    availability: 'available',
    verifiedStatus: 'verified',
    postedDate: new Date(),
  },
  {
    propertyID: 'seed-006',
    sourceName: 'Property24 Kenya',
    sourceID: 'p24-002',
    title: '3 Bedroom Maisonette in Ruaka',
    description: 'Spacious 3 bedroom maisonette in a gated community. DSQ, ample parking, and a communal garden.',
    price: 9500000,
    currency: 'KES',
    listingType: 'for-sale',
    propertyType: 'house',
    county: 'Kiambu',
    town: 'Ruaka',
    estate: 'Ruaka',
    bedrooms: 3,
    bathrooms: 2,
    size: 180,
    furnished: false,
    serviced: false,
    propertyImages: [
      { url: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994' },
    ],
    location: {
      type: 'Point',
      coordinates: [36.7790, -1.2100],
    },
    isPublished: true,
    isFeatured: false,
    availability: 'available',
    verifiedStatus: 'pending',
    postedDate: new Date(),
  },
];

const seedData = async () => {
  try {
    console.log('[Seed] Connecting to database...');
    await connectDB();

    console.log('[Seed] Clearing existing AggregatedProperty data...');
    await AggregatedProperty.deleteMany({});

    console.log('[Seed] Inserting sample properties...');
    const inserted = await AggregatedProperty.insertMany(sampleProperties);

    console.log(`[Seed] Successfully inserted ${inserted.length} properties!`);
    console.log('[Seed] Sample properties:');
    inserted.forEach((p, i) => {
      console.log(`  ${i + 1}. ${p.title} - ${p.price} ${p.currency} (${p.listingType})`);
    });

    process.exit(0);
  } catch (error) {
    console.error('[Seed] Error:', error.message);
    process.exit(1);
  }
};

seedData();