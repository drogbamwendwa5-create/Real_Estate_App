/**
 * Property Aggregation System - Scheduler Configuration
 *
 * Cron schedules for scraping, updates, ranking, validation, and cleanup jobs.
 * Each scraper runs with a 5-minute runtime limit (300,000ms) to ensure
 * timely completion and prevent resource exhaustion.
 */
module.exports = {
  // Scraper schedules (cron expressions)
  schedules: {
    // Every 2 hours - new listings and updates (each scraper runs for up to 5 minutes)
    scraperUpdate: '0 */2 * * *',

    // Every 6 hours - ranking updates
    ranking: '0 */6 * * *',

    // Every 24 hours at 2 AM - validation
    validation: '0 2 * * *',

    // Every 24 hours at 3 AM - cleanup
    cleanup: '0 3 * * *',

    // Every 24 hours at 4 AM - image validation
    imageValidation: '0 4 * * *',

    // Every 24 hours at 5 AM - duplicate detection
    duplicateDetection: '0 5 * * *',

    // Every 12 hours - cache warmup
    cacheWarmup: '0 */12 * * *',

    // Every 1 hour - price history snapshot
    priceHistory: '0 * * * *',
  },

  // Job concurrency limits
  concurrency: {
    scraper: 3,        // Max 3 concurrent scrapers
    validator: 5,      // Max 5 concurrent validation tasks
    imageValidator: 10, // Max 10 concurrent image checks
    duplicateDetector: 2, // Max 2 concurrent duplicate detection runs
  },

  // Job timeouts (in milliseconds)
  timeouts: {
    scraper: 300000,       // 5 minutes per scraper (with image validation)
    validation: 600000,    // 10 minutes for full validation run
    imageValidation: 900000, // 15 minutes for image validation
    duplicateDetection: 1200000, // 20 minutes for duplicate detection
    ranking: 300000,       // 5 minutes for ranking
    cleanup: 600000,       // 10 minutes for cleanup
  },

  // Retry configuration
  retries: {
    maxAttempts: 3,
    backoffMs: 5000,
    backoffMultiplier: 2,
  },

  // Timezone for cron jobs
  timezone: 'Africa/Nairobi',

  // Whether to run jobs on startup (for development)
  runOnStartup: false,
};