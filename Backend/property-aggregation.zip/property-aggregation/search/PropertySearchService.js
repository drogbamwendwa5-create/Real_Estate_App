const AggregatedProperty = require("../database/AggregatedProperty");
const PropertyCacheService = require("../cache/PropertyCacheService");
const cc = require("../config/cache.config");

class PropertySearchService {
  constructor() {
    this.cache = new PropertyCacheService();
  }

  async search(query) {
    const cacheKey = cc.keys.search(query);
    return await this.cache.getOrSet(cacheKey, async () => {
      const m = { isPublished: true };
      if (query.listingType) m.listingType = query.listingType;
      if (query.propertyType) m.propertyType = query.propertyType;
      if (query.county) m.county = query.county;
      if (query.town) m.town = query.town;
      if (query.minPrice || query.maxPrice) {
        m.price = {};
        if (query.minPrice) m.price.$gte = parseInt(query.minPrice);
        if (query.maxPrice) m.price.$lte = parseInt(query.maxPrice);
      }
      if (query.bedrooms) m.bedrooms = parseInt(query.bedrooms);
      if (query.bathrooms) m.bathrooms = parseInt(query.bathrooms);
      const props = await AggregatedProperty.find(m).sort({ rankingScore: -1, postedDate: -1 }).limit(parseInt(query.limit) || 50).lean();
      return { count: props.length, data: props };
    }, cc.ttl.searchResults);
  }

  async getNew(limit) {
    return await AggregatedProperty.find({ isPublished: true }).sort({ postedDate: -1 }).limit(limit || 20).lean();
  }

  async getFeatured(limit) {
    return await AggregatedProperty.find({ isPublished: true, isFeatured: true }).sort({ rankingScore: -1 }).limit(limit || 10).lean();
  }

  async getVerified(limit) {
    return await AggregatedProperty.find({ isPublished: true, verifiedStatus: "verified" }).sort({ rankingScore: -1 }).limit(limit || 10).lean();
  }

  async getSimilar(id, limit) {
    const p = await AggregatedProperty.findById(id).lean();
    if (!p) return [];
    return await AggregatedProperty.find({ _id: { $ne: id }, propertyType: p.propertyType, listingType: p.listingType, county: p.county, isPublished: true }).sort({ rankingScore: -1 }).limit(limit || 10).lean();
  }
}

module.exports = PropertySearchService;
